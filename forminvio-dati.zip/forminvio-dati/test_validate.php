<?php
include "./Validate.php";


function test($assert, $result, $line)
{

	echo $assert === $result ? "" : "fail (line " . $line . ")\n";
}

$validator = new Validator();


echo $validator->required('roberto@a.it') === true ? "" : "fail (line " . __LINE__ . ")\n";
echo $validator->required('') === false ? "" : "fail (line " . __LINE__ . ")\n";
echo $validator->required('  ') === false ? "" : "fail (line " . __LINE__ . ")\n";

echo $validator->email('a') === false ? "" : "fail (line " . __LINE__ . ")\n";
echo $validator->email('a@b.it') === true ? "" : "fail (line " . __LINE__ . ")\n";



test($validator->getOptionsRequired(), false, __LINE__);
test($validator->getOptionsRequired(['required' => true]), true, __LINE__);
test($validator->getOptionsRequired(['required' => false]), false, __LINE__);




echo $validator->name('a@b.it') === false ? "" : "fail (line " . __LINE__ . ")\n";
echo $validator->name('marco rosso') === true ? "" : "fail (line " . __LINE__ . ")\n";
echo $validator->name('marco') === true ? "" : "fail (line " . __LINE__ . ")\n";
echo $validator->name('3marco rosso') === false ? "" : "fail (line " . __LINE__ . ")\n";
echo $validator->name('33') === false ? "" : "fail (line " . __LINE__ . ")\n";
echo $validator->name('lica5') === false ? "" : "fail (line " . __LINE__ . ")\n";
echo $validator->name('lica5', array('required' => true)) === false ? "" : "fail (line " . __LINE__ . ")\n";
echo $validator->name('', array('required' => true)) === false ? "" : "fail (line " . __LINE__ . ")\n";
echo $validator->name('', array('required' => false)) === true ? "" : "fail (line " . __LINE__ . ")\n";
